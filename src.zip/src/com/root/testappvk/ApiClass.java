package com.root.testappvk;

import com.perm.kate.api.Api;

import android.app.Application;

public class ApiClass extends Application {
	private static Api sApi;
	private static Account sAccount;
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		sAccount=new Account();
		sAccount.restore(this);
	}
	public static Api getApi() {
		if (sApi == null) {
			sApi = new Api(sAccount.access_token, Constants.API_ID);
		}
		return sApi;
	}
	
	public static Account getAccount() {
		if(sAccount == null) {
			sAccount = new Account();
		}
		return sAccount;
	}
}
