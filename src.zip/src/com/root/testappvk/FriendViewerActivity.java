package com.root.testappvk;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;

import org.json.JSONException;

import com.perm.kate.api.Api;
import com.perm.kate.api.KException;
import com.perm.kate.api.User;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class FriendViewerActivity extends Activity implements OnClickListener{
	long uid;
	Api api;
	private TextView mFriendName;
	private ImageView mFriendAvatar;
	private TextView mItsFriend;
	private Button mShowPhotosButton;
	Intent in;
	Bitmap bitmap;
	FriendViewerTask task;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.friend_viewer);
		getActionBar().hide();
		
		
		task = new FriendViewerTask();
		task.execute();
		createUI();
	}
	
	
	private void createUI() {
		mFriendName = (TextView)findViewById(R.id.friend_name);
		mFriendAvatar = (ImageView)findViewById(R.id.friend_avatar_big);
		mItsFriend = (TextView)findViewById(R.id.its_your_friend);
		mShowPhotosButton = (Button)findViewById(R.id.button1);
		mShowPhotosButton.setOnClickListener(this);
	}
	
	class FriendViewerTask extends AsyncTask<Void, Void, Void> {
		Collection<Long> uids = new ArrayList<Long>();
		ArrayList<User> users;
		User friend;
		@Override
		protected Void doInBackground(Void... params) {
			in = getIntent();	
			uid = in.getLongExtra("uid", 0);
			uids.add(uid);
			try {
				api = ApiClass.getApi();
				users = api.getProfiles(uids, null, null, null, null, null);
				for (int i = 0; i<users.size(); i++){
					friend = users.get(i);					
					bitmap = BitmapFactory.decodeStream(new URL(friend.photo_big).openStream());
				}
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (KException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			mFriendName.setText(friend.first_name+"  "+friend.last_name);
			if(friend.sex != null) {
				switch (friend.sex) {
				case 1:
					mItsFriend.setText("��� ���� �������");
					break;
				case 2:
					mItsFriend.setText("��� ���� ����");
					break;
				}
			}
			mFriendAvatar.setImageBitmap(bitmap);			
			super.onPostExecute(result);
		}
		
	}


	@Override
	public void onClick(View view) {
		switch(view.getId()) {
		case R.id.button1:
			Intent intent = new Intent(FriendViewerActivity.this, PhotoGalleryActivity.class);
			intent.putExtra("uid", uid);
			startActivity(intent);
		
		}
		
	}
}
