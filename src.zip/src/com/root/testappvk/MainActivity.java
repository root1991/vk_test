package com.root.testappvk;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;

import org.json.JSONException;

import com.perm.kate.api.Api;
import com.perm.kate.api.KException;
import com.perm.kate.api.User;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {

	private static final String HI = "������,";
	private static final String ON_WALL_POST_OK = "������ ������������";
	private final int REQUEST_LOGIN = 1;
	
	private Button authorizeButton;
	private Button logoutButton;
	private Button postButton;
	private Button showFriends;
	private EditText messageEditText;
	private ImageView mAvaImage;
	private TextView mHiTextView;
	private TextView mUserNameTextView;
	private TextView head;
	private Account account = new Account();
	private Api api;
	private MyInformationTask mTask;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		getActionBar().hide();
		setupUI();
		account.restore(this);
		if (account.access_token != null) {
			api = ApiClass.getApi();
		} else {

		}

		showButtons();
	}

	@Override
	protected void onStart() {
		if (api != null) {
			mTask = new MyInformationTask();
			mTask.execute();
		}
		super.onStart();
	}

	private void setupUI() {
		showFriends = (Button) findViewById(R.id.showFriends);
		showFriends.setOnClickListener(this);

		mAvaImage = (ImageView) findViewById(R.id.imageAva);

		authorizeButton = (Button) findViewById(R.id.authorize);
		authorizeButton.setOnClickListener(this);

		logoutButton = (Button) findViewById(R.id.logout);
		logoutButton.setOnClickListener(this);

		postButton = (Button) findViewById(R.id.post);
		postButton.setOnClickListener(this);

		messageEditText = (EditText) findViewById(R.id.message);

		mHiTextView = (TextView) findViewById(R.id.hi_user);
		mUserNameTextView = (TextView) findViewById(R.id.user_name);
		
		head =(TextView)findViewById(R.id.textView1);
	}

	private void startLoginActivity() {
		Intent intent = new Intent();
		intent.setClass(this, LoginActivity.class);
		startActivityForResult(intent, REQUEST_LOGIN);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == REQUEST_LOGIN) {
			if (resultCode == RESULT_OK) {
				account.access_token = data.getStringExtra("token");
				account.user_id = data.getLongExtra("user_id", 0);
				account.save(MainActivity.this);
				api = new Api(account.access_token, Constants.API_ID);
				mTask = new MyInformationTask();
				mTask.execute();
				showButtons();

			}
		}
	}

	private void postToWall() {
		new Thread() {
			@Override
			public void run() {
				try {
					String text = messageEditText.getText().toString();
					api.createWallPost(account.user_id, text, null, null,
							false, false, false, null, null, null, null);
					messageEditText.setText("");

					runOnUiThread(successRunnable);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}.start();
	}

	private void showFriendsActivity() {
		Intent intent = new Intent(MainActivity.this, SecondActivity.class);
		intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
		startActivity(intent);
	}

	Runnable successRunnable = new Runnable() {
		@Override
		public void run() {
			Toast.makeText(getApplicationContext(),
					ON_WALL_POST_OK,
					Toast.LENGTH_LONG).show();
		}
	};

	private void logOut() {
		api = null;
		account.access_token = null;
		account.user_id = 0;
		account.save(MainActivity.this);
		showButtons();
	}

	void showButtons() {
		if (api != null) {
			authorizeButton.setVisibility(View.GONE);
			head.setVisibility(View.GONE);
			logoutButton.setVisibility(View.VISIBLE);
			postButton.setVisibility(View.VISIBLE);
			messageEditText.setVisibility(View.VISIBLE);
			mAvaImage.setVisibility(View.VISIBLE);
			mHiTextView.setVisibility(View.VISIBLE);
			mUserNameTextView.setVisibility(View.VISIBLE);
			showFriends.setVisibility(View.VISIBLE);
		} else {
			authorizeButton.setVisibility(View.VISIBLE);
			head.setVisibility(View.VISIBLE);
			logoutButton.setVisibility(View.GONE);
			postButton.setVisibility(View.GONE);
			messageEditText.setVisibility(View.GONE);
			mAvaImage.setVisibility(View.GONE);
			mHiTextView.setVisibility(View.GONE);
			mUserNameTextView.setVisibility(View.GONE);
			showFriends.setVisibility(View.GONE);
		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.authorize:
			startLoginActivity();
			break;
		case R.id.logout:
			logOut();
			break;
		case R.id.post:
			postToWall();
			break;
		case R.id.showFriends:
			showFriendsActivity();
			break;
		}
	}

	class MyInformationTask extends AsyncTask<Void, Void, Void> {
		Collection<Long> uids = new ArrayList<Long>();
		ArrayList<User> users;
		User my;
		Bitmap bitmap;

		@Override
		protected Void doInBackground(Void... params) {
			uids.add(account.user_id);
			try {

				users = api.getProfiles(uids, null, null, null, null, null);
				for (int i = 0; i < users.size(); i++) {
					my = users.get(i);
					bitmap = BitmapFactory.decodeStream(new URL(my.photo_big)
							.openStream());
				}

			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (KException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			mAvaImage.setImageBitmap(bitmap);
			mHiTextView.setText(HI);
			mUserNameTextView.setText(my.first_name + "  " + my.last_name);
			super.onPostExecute(result);
		}

	}

}