package com.root.testappvk;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;

import org.json.JSONException;

import com.perm.kate.api.Api;
import com.perm.kate.api.KException;
import com.perm.kate.api.User;
import com.root.testappvk.friendslist.FriendsAdapter;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

public class SecondActivity extends Activity {
	private ListView listView;
	private FriendsAdapter adapter;
	private List<User> friends;
	private FriendsAsync async;
	private Account account;
	private Api api;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.second_activity);
		getActionBar().hide();
		listView = (ListView)findViewById(R.id.listView1);
		account = ApiClass.getAccount();
		account.restore(SecondActivity.this);
		api = ApiClass.getApi();
		if(api!=null) {
			async = new FriendsAsync();
			async.execute();
		}
		listView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position,
					long id) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(SecondActivity.this, FriendViewerActivity.class);
				intent.putExtra("uid", id);
				startActivity(intent);
			}
		});
	}

	public class FriendsAsync extends AsyncTask<Void, Void, Void> {

		@Override
		protected Void doInBackground(Void... params) {
			try {
				
			
				friends = api.getFriends(
						account.user_id, null, null, null, null);
				Log.d("ppp", friends.toString());
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (KException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			
			adapter = new FriendsAdapter(SecondActivity.this, friends);
			listView.setAdapter(adapter);
			
			super.onPostExecute(result);
		}
				
	}

}
