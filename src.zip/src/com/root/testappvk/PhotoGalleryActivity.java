package com.root.testappvk;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;

import org.json.JSONException;

import com.perm.kate.api.Api;
import com.perm.kate.api.KException;
import com.perm.kate.api.Photo;
import com.root.testappvk.friendslist.GalleryAdapter;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;

public class PhotoGalleryActivity extends Activity implements OnItemClickListener {
	private static final String UID = "uid";
	private static final String THIS_LINK = "this link";
	
	private Api api;
	private long uid;
	private String st;
	private GetPhotoLinksAsync async;
	private GridView gridView;
	private GalleryAdapter adapter;
	private ArrayList<String> links = new ArrayList<String>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.photo_gallery);
		Intent in = getIntent();
		createUI();
		uid = in.getLongExtra(UID, 0);
		async = new GetPhotoLinksAsync();
		async.execute();
		
	}
	
	private void createUI() {
		gridView = (GridView) findViewById(R.id.grid_view);
		gridView.setOnItemClickListener(this);
	}

	class GetPhotoLinksAsync extends AsyncTask<Void, Void, Void> {

		@Override
		protected Void doInBackground(Void... params) {
			ArrayList<Photo> listOfPhotos;
			Photo photo;
			try {
				api = ApiClass.getApi();
				listOfPhotos = api.getAllPhotos(uid, null, 100, true);
				for (int i = 0; i < listOfPhotos.size(); i++) {
					photo = listOfPhotos.get(i);
					st = photo.src_big;
					links.add(st);
				}
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (KException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			adapter = new GalleryAdapter(PhotoGalleryActivity.this, links);
			gridView.setAdapter(adapter);
		}

	}
	
	@Override
	public void onItemClick(AdapterView<?> parend, View v, int position, long id) {
		Intent i = new Intent(PhotoGalleryActivity.this, FullImageActivity.class);
		i.putExtra(THIS_LINK, links.get(position));
		startActivity(i);		
	}
}
