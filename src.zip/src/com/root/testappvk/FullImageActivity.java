package com.root.testappvk;

import com.root.testappvk.imagecache.ImageLoader;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

public class FullImageActivity extends Activity {
	private static final String THIS_LINK = "this link";
	private ImageLoader il; 
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.full_image);
        getActionBar().hide();
        il = new ImageLoader(this);
        Intent i = getIntent();
        String thisLink = i.getStringExtra(THIS_LINK);
        ImageView imageView = (ImageView) findViewById(R.id.full_image_view);
        il.DisplayImage(thisLink, imageView);
    }
 
}