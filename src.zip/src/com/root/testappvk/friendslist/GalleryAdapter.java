package com.root.testappvk.friendslist;

import java.util.ArrayList;

import com.root.testappvk.imagecache.ImageLoader;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

public class GalleryAdapter extends BaseAdapter {
	private Context context;
	private ArrayList<String> links;
	private ImageLoader il;
	
	public GalleryAdapter(Context context, ArrayList<String> links) {
		this.context = context;
		this.links = links;
		il = new ImageLoader(context);
	}
	@Override
	public int getCount() {
		return links.size();
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ImageView imageView = new ImageView(context);
		for(int i=0; i<links.size(); i++) {
			il.DisplayImage(links.get(i), imageView);
		}
		il.DisplayImage(links.get(position), imageView);
		imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        imageView.setLayoutParams(new GridView.LayoutParams(170, 170));
		return imageView;
	}

}
