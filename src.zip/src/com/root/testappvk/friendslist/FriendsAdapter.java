package com.root.testappvk.friendslist;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.perm.kate.api.User;
import com.root.testappvk.R;
import com.root.testappvk.imagecache.ImageLoader;

public class FriendsAdapter extends BaseAdapter {
	List<User> friendsUsers;
	private LayoutInflater inflater;
	Context context;
	ImageView userAvatarImageView;
	User oneFriend;
	ImageLoader il;
	
	public FriendsAdapter(Context context, List<User> friendsUsers) {
		inflater = LayoutInflater.from(context);
		this.context = context;
		this.friendsUsers = friendsUsers;
		il = new ImageLoader(context);
	}
	
	@Override
	public int getCount() {
		return friendsUsers.size();
	}

	public List<User> getFriendsUsers() {
		return friendsUsers;
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		User friend = friendsUsers.get(position);
		if (friend != null) {
			return friend.uid;
		}
		return 0;
	}

	static class ViewHolder {
		protected TextView text;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		final View realView;
		if (convertView == null) {
			realView = inflater.inflate(R.layout.item, null);
		} else {
			realView = convertView;
		}
		TextView justName = (TextView) realView.findViewById(R.id.justName);
		userAvatarImageView = (ImageView) realView.findViewById(R.id.avatar);
		ImageView isOnline = (ImageView) realView.findViewById(R.id.is_online);	
		int newposition = position +1;
		String[] data = new String[newposition];
		for(int i = 0; i<data.length; i++) {
			oneFriend = friendsUsers.get(i);
			data[i] = oneFriend.photo_medium;
			justName.setText(oneFriend.first_name + "  " + oneFriend.last_name);
			il.DisplayImage(data[i], userAvatarImageView);
			
			if(oneFriend.online) {
				isOnline.setVisibility(View.VISIBLE);
			} else {
				isOnline.setVisibility(View.GONE);
			}
		}
		
		//
		// TODO Auto-generated method stub
		return realView;
	}
}
